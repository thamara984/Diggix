<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Authentication  
 *
 * @version     1.0.0.0
 * @package     auth-api
 * @subpackage  controllers/authentication
 * @category    Controller
 * @author      Lahiru
 * @link        https://auth-api.insureme.lk
 */
class Authentication extends INME_Controller
{
    function __construct()
	{
        parent::__construct();
		$this->load->library('nusoap_library');
		$this->load->helper('security');
        $this->load->library('authentication/Authentication_lib');
	}
    
    /* Authentication API SERVICE */	
	public function server()
	{
		global $server;
		$GLOBALS['this'] = $this;
		$ns = base_url('authentication/1.0.0.0/Authentication/server');

		$server = new nusoap_server;
		$server->configureWSDL('AUTHENTICATION API', $ns);
		$server->soap_defencoding = 'UTF-8';
		$server->wsdl->schemaTargetNamespace = $ns;

		/* Operation 1 : Authentication */
		$input_params 	= array 
		(
			'user_name'	=> 'xsd:string',
			'password'	=> 'xsd:string',
			'api_key'	=> 'xsd:string',
		);

		$response 	= array 
		(
			'authentication_response' => 'xsd:Array'
		);

		$server->register
		(
			'authentication',
			$input_params,
			$response,
			'urn:SOAPServerWSDL',
			'urn:' . $ns . '/authentication',
			'rpc',
			'encoded',
			'Authentication'
		);
		
		/* Operation 2 : Auth key verification */
		$input_params 	= array 
		(
			'auth_key'	=> 'xsd:string',
		);

		$response 	= array 
		(
			'auth_key_verify_response' => 'xsd:Array'
		);

		$server->register
		(
			'auth_key_verify',
			$input_params,
			$response,
			'urn:SOAPServerWSDL',
			'urn:' . $ns . '/auth_key_verify',
			'rpc',
			'encoded',
			'Authentication'
        );

        function authentication($input_array) 
		{
		
			$input_array     				= $GLOBALS['this']->security->xss_clean($input_array);
			global $server;
			$input_array['api_key']     	= $server->requestHeader['api_key'];
			$input_array['password']    	= md5($input_array['password']);	 
			array_replace_recursive($input_array, $input_array);
			
			/* Authentication validation */
			$validation_result = $GLOBALS['this']->authentication_lib->authentication($input_array);

            return json_encode($validation_result);
		}

		function auth_key_verify($input_array)
		{
			$input_array     				= $GLOBALS['this']->security->xss_clean($input_array);
			global $server;
			$input_array['ws_auth_key'] 	= $server->requestHeader['auth_key'];
			$input_array['ws_operation']	= $input_array['ws_utiliies']['ws_operation'];
			$input_array['ws_url']			= $input_array['ws_utiliies']['ws_url'];
			$input_array['secret_key']    	= $input_array['client_data']['auth_key'];
			$validation_result 				= $GLOBALS['this']->authentication_lib->auth_key_verify($input_array);
			return json_encode($validation_result);
		}
        
        $server->service(file_get_contents("php://input"));
    }
    
}
/* End of file Authentication.php */
/* Location: ./application/controllers/authentication/Authentication.php */
