<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Authentication
 *
 * @version     1.1.0.0
 * @package     auth-api
 * @subpackage  controllers/v12
 * @category    Controller
 * @author      Lahiru
 */
require APPPATH . 'libraries/rest-lib/REST_Controller.php';

class Authentication extends REST_Controller
{
    function __construct()
	{
        parent::__construct();
	    $this->load->library('authentication/Authentication_lib');
	}

    /* Authentication request */
	function auth_post()
	{
		$input_array 				= $this->post();
		$headers					= $this->input->request_headers();
		if(array_key_exists('api_key', $headers) && array_key_exists('user_name',
		   $input_array) && array_key_exists('password', $input_array))
		{
			$input_array['api_key']		= $headers['api_key'];
			$input_array['password']    	= md5($input_array['password']);
			array_replace_recursive($input_array, $input_array);
			// /* Authentication validation */
			$validation_result = $this->authentication_lib->authentication($input_array);
			$this->response($validation_result);
		}
		else
		{
			$message = ['error' => 'Bad Request'];
			$this->response($message, REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	/* Auth key verification */
	function verify_post()
	{
		$input_array 				= $this->post();
		$headers					= $this->input->request_headers();
        if(array_key_exists('auth_key', $headers) && array_key_exists('ws_utilities',
		   $input_array) && array_key_exists('ws_operation', $input_array['ws_utilities']) &&
		   array_key_exists('ws_url', $input_array['ws_utilities'])  &&
		   array_key_exists('client_data', $input_array) && array_key_exists('auth_key', $input_array['client_data']))
		{
			$input_array['ws_auth_key'] 	= $headers['auth_key'];
			$input_array['ws_operation']	= $input_array['ws_utilities']['ws_operation'];
			$input_array['ws_url']			= $input_array['ws_utilities']['ws_url'];
			$input_array['secret_key']    	= $input_array['client_data']['auth_key'];
			$validation_result 				= $this->authentication_lib->auth_key_verify($input_array);
			$this->response($validation_result);
		}
		else
		{
			$message = ['error' => 'Bad Request'];
			$this->response($message, REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}
/* End of file Authentication.php */
/* Location: ./application/controllers/authentication/v11/Authentication.php */
