<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication_tester extends CI_Controller {
    
    function __construct()
	{
        parent::__construct();
        $this->load->library('nusoap_library');
  	}
    public function authentication_req() 
	{
		$ws_url = "https://auth-api.insureme.lk/authentication/1.0.0.0/Authentication?wsdl";
		
		$client = new nusoap_client($ws_url);

        $api_key = '7d3ONnlI6MEA8LZpJ4L331JQ5b23T22D';

        $header = 
        (
			"<api_key>" . htmlspecialchars($api_key) . "</api_key>"
		);

        $input_array = array
		(
			'input_array' => array
		    (
			    'user_name' => '002SCQOTONLD',
				'password' => 'medmaponl@1010'	
			)
        );

        $client->setHeaders($header);
        $results = $client->call('authentication', $input_array);
        $arr = json_decode($results,TRUE);
        print_r($arr); 
        $this->ws_debug($client);
	}
	
	public function auth_key_verify_req() 
	{
		$ws_url = "http://auth-api.inme.lk/authentication/v1.0.0.0/Authentication?wsdl";
		
		$client = new nusoap_client($ws_url);
        $input_array = array
		(
			'input_array' => array
		    (
			    'auth_key' => '3434343',
			)
        );

        $results = $client->call('auth_key_verify', $input_array);
        $arr = json_decode($results,TRUE);
        print_r($arr); 
        $this->ws_debug($client);
    }

    /* Web service client debug */
	private function ws_debug($client)
	{
		print_r('<pre>');
		echo "<h2>Request</h2>";
		echo "<pre>" . htmlspecialchars($client->request, ENT_QUOTES) . "</pre>";
		echo "<h2>Responses</h2>";
		echo "<pre>" . htmlspecialchars($client->response, ENT_QUOTES) . "</pre>";
		echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->debug_str, ENT_QUOTES) . '</pre>';
	}

	function test()
	{
		redirect('authentication/1.0.0.0/Authentication');
	}
}