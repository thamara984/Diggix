<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Authentication library model  
 *
 * @package     auth-api
 * @subpackage  models/authentication
 * @category    Model
 * @author      Lahiru
 * @link        https://auth-api.insureme.lk
 */
class Authentication_lib_model extends CI_Model 
{
    function __construct()
	{
        parent::__construct();
        $this->load->database('default',TRUE);
    }

    function validate_credentials($input_array)
	{
        $this->db->select
        (
            'user.id AS user_id,
            user.fk_api_id AS api_id'
        );
        $this->db->from($this->db->database.'.data_api_user user');
        $this->db->where('user.user_name',$input_array['user_name']);
        $this->db->where('user.password',$input_array['password']);
        $this->db->where('user.api_key',$input_array['api_key']);       
        $this->db->where('user.status',1);
        $reuslt     = $this->db->get();
        if($reuslt->num_rows() == 1)
        {
            return $reuslt->result_array()[0];
        }
        else
        {
            return FALSE;
        }
        
    }
    
    // get valid auth key
    function get_valid_auth_key($input_array)
    {
        $this->db->select('secret_key,UNIX_TIMESTAMP(exp_at) AS exp_at');
		$this->db->from($this->db->database.'.data_api_usage usage');
		$this->db->where('exp_at >', 'NOW()', FALSE);
        $this->db->where('usage.fk_user_id', $input_array['fk_user_id']);
        $this->db->where('usage.fk_api_id', $input_array['fk_api_id']);
        $this->db->where('usage.status',1);
		$query = $this->db->get();
		if ($query->num_rows()==1)
		{
			$row 	= $query->row();
			return array('auth_key'	=> $row->secret_key,'expires_in' => $row->exp_at);
		}
		else
		{
			$this->load->helper('string');
            $insert_array['secret_key'] 	= random_string('alnum', 32);
            $input_array['secret_key']      = $insert_array['secret_key'];
            $insert_array['fk_user_id']     = $input_array['fk_user_id'];
            $insert_array['fk_api_id']      = $input_array['fk_api_id'];
            $this->db->set('exp_at', 'NOW() + INTERVAL 1 DAY', FALSE);
            
            $this->db->insert($this->db->database.'.data_api_usage', $insert_array); 
			$result 	= ($this->db->affected_rows() > 0) ? TRUE : FALSE;
			if($result)
			{
				return $this->validate_auth_key($input_array,FALSE,TRUE);
                 
			}
			else
			{
				return FALSE;
			}
		}   
    }

    // validate auth key
    private function validate_auth_key($input_array, $app_code = FALSE, $has_secret_key = TRUE)
	{
	    if($app_code == TRUE)
        {
            $this->db->select('usage.secret_key,api.api_code');
            $this->db->from($this->db->database.'.data_api_usage usage');
            $this->db->join($this->db->database.'.conf_api api','api.id = usage.fk_api_id');
            $this->db->where('usage.secret_key', $input_array['secret_key']);
            $this->db->where('usage.exp_at >', 'NOW()', FALSE);
            $this->db->where('usage.status',1);
            $this->db->where('api.status',1);
            $query = $this->db->get();
            if ($query->num_rows()==1)
            {
              return $query->result_array()[0];
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            $this->db->select('usage.secret_key,UNIX_TIMESTAMP(exp_at) AS exp_at');
            $this->db->from($this->db->database.'.data_api_usage usage');
            if($has_secret_key == TRUE)
            {
                $this->db->where('usage.secret_key', $input_array['secret_key']);
            }
            else
            {
                $this->db->where('usage.fk_user_id', $input_array['fk_user_id']);
                $this->db->where('usage.fk_api_id', $input_array['fk_api_id']);
            }
            $this->db->where('usage.exp_at >', 'NOW()', FALSE);
            $this->db->where('usage.status',1);
            $query = $this->db->get();
            if ($query->num_rows()==1)
            {
                return array('auth_key'	=> $query->result_array()[0]['secret_key'],
                             'expires_in' => $query->result_array()[0]['exp_at']);
            }
            elseif($query->num_rows() > 1)
            {
                return array('error','Error, Something went wrong with generating authentication key');
            }
            else
            {
                return FALSE;
            }
        }
        
    }
    
    // verify auth key verify
    function auth_key_verify($input_array)
    {
        $response = $this->validate_auth_key($input_array,TRUE);
        if($response != FALSE)
        {
            return array('auth_status' => 'Ok','api_code' => $response['api_code']);
        }
        else
        {
            return FALSE;
        }
    }

    // operation verification
    function get_operation_verify($input_array)
    {
        $this->db->select
        (
            'api.id AS api_id,
            api.url_test,
            api.url_dr,
            api.url_live,
            api_status'
        );
        $this->db->from($this->db->database.'.data_api_usage usage');
        $this->db->join($this->db->database.'.conf_api api','api.id = usage.fk_api_id');
        $this->db->join($this->db->database.'.conf_api_operation oper','oper.fk_api_id = usage.fk_api_id');
        $this->db->where('usage.secret_key', $input_array['ws_auth_key']);
        $this->db->where('oper.operation_name', $input_array['ws_operation']);
        $this->db->where('usage.exp_at >', 'NOW()', FALSE);
        $this->db->where('usage.status',1);
        $this->db->where('oper.status',1);
        $this->db->where('api.status',1);
        $result  = $this->db->get();
        if($result->num_rows() == 1)
        {
            return $result->result_array()[0];
        }
        else
        {
            return FALSE;
        }
    }
}
/* End of file Authentication_lib_model.php */
/* Location: ./application/models/authentication/Authentication_lib_model.php */