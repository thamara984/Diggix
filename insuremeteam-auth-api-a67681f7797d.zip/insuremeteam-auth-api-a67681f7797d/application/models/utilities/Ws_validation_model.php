<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Ws Validation model  
 *
 * @package     auth-api
 * @subpackage  models/utilities
 * @category    Model
 * @author      Lahiru
 * @link        https://auth-api.insureme.lk
 */
class Ws_validation_model extends CI_Model 
{
    function __construct()
	{
        parent::__construct();
        $this->load->database('default',TRUE);
    }


}
/* End of file Ws_validation_model.php */
/* Location: ./application/models/utilities/Ws_validation_model.php */