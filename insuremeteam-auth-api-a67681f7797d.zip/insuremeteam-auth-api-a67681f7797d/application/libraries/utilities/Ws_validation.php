<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Ws Validation library
 *
 * @package     auth-api
 * @subpackage  libraries/utilities
 * @category    Library
 * @author      Lahiru
 * @link        https://auth-api.insureme.lk
 */
class Ws_validation 
{
    function __construct()
	{
        $this->cim	= & get_instance();
        $this->cim->load->model('utilities/Ws_validation_model');
        $this->cim->load->library("form_validation");
    }

    // authentication validation
    function authentication_validation($input_array)
    {
        $form   = 'authentication';
		$this->cim->form_validation->set_data($input_array);
		if($this->cim->form_validation->run($form)===FALSE)
		{               
			return array('error'    => $this->cim->form_validation->error_array());
		}
		else
		{
            return $input_array;
        }
    }

    //authentication verification validation
    function auth_key_verify_validation($input_array)
    {
        $form   = 'auth_key_verify';
		$this->cim->form_validation->set_data($input_array);
		if($this->cim->form_validation->run($form)===FALSE)
		{               
			return array('error'    => $this->cim->form_validation->error_array());
		}
		else
		{
            return $input_array;
        }
    }
}
/* End of file Ws_validation.php */
/* Location: ./application/libraries/utilities/Ws_validation.php */