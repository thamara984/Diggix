<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Authentication library
 *
 * @package     auth-api
 * @subpackage  libraries/authentication
 * @category    Library
 * @author      Lahiru
 * @link        https://auth-api.insureme.lk
 */
class Authentication_lib extends INME_Controller
{
    function __construct()
	{
        $this->cim	= & get_instance();
        $this->cim->load->model('authentication/Authentication_lib_model');
        $this->cim->load->library('utilities/Ws_validation');
    }
    
    function authentication($input_array)
    {
	$res_validate_data      = $this->cim->ws_validation->authentication_validation($input_array);
        if(array_key_exists('error',$res_validate_data))
        {
		
            return $this->set_error_message(1, 801, 'Missing required authentication parameters', $res_validate_data['error']);
        }elseif(!empty($res_validate_data))
        {
             $res_validate_credentials   = $this->cim->Authentication_lib_model->validate_credentials($input_array);
            if($res_validate_credentials != FALSE)
            {
                $input_array['fk_user_id']  = $res_validate_credentials['user_id'];
                $input_array['fk_api_id']   = $res_validate_credentials['api_id'];
                $res_validate_auth_key      = $this->cim->Authentication_lib_model->get_valid_auth_key($input_array);
                if($res_validate_auth_key != FALSE)
                {
                    return $this->set_success_message($res_validate_auth_key);    
                }
                else
                {
                    return $this->set_error_message(0, 804, 'Couldn\'t generate authentication key, please try again');
                }
            }
            else
            {
                return $this->set_error_message(0, 803, 'Wrong authentication credentials');
            }
        }
        else
        {
            return $this->set_error_message(0, 802, 'Something went wrong with the authentication service');
        }
    }

    

    // Auth key verification
    function auth_key_verify($input_array)
    {
        unset($input_array['ws_utilities']);
        unset($input_array['client_data']);
        $res_validate_data      = $this->cim->ws_validation->auth_key_verify_validation($input_array);
        if(array_key_exists('error',$res_validate_data))
        {
            return $this->set_error_message(1, 805, 'Missing required auth key verification parameters', $res_validate_data);
        }elseif(!empty($res_validate_data))
        {
            $res_operation_verify   = $this->cim->Authentication_lib_model->get_operation_verify($input_array);
            if($res_operation_verify != FALSE)
            {
                $res_validate_operation     = $this->validate_operation($res_operation_verify,$input_array);
                if($res_validate_operation == TRUE)
                {
                    $res_auth_key_response  = $this->cim->Authentication_lib_model->auth_key_verify($input_array);
                    if($res_auth_key_response != FALSE)
                    {
                        return $this->set_success_message($res_auth_key_response);
                    }
                    else
                    {
                        return $this->set_error_message(0, 809, 'Couldn\'t validate client authentication key, Please try again');
                    }
                }
                else
                { 
                    return $this->set_error_message(0, 808, 'Coudn\'t  validate the web service our system');
                }
            }
            else
            {
                return $this->set_error_message(0, 807, 'Coudn\'t  find the operation on this web service');
            }
           
        }
        else
        {
            return $this->set_error_message(0, 806, 'Something went wrong with the auth key verification service');
           
        }
    }

    // validate operation
    private function validate_operation($res_db,$input_array)
    {
        $valid_url          = FALSE;
        $response           = array();
        if($res_db['api_status'] == 1)
        {
            // ws in developing
            return $this->check_result_set_response
            (
                $res_db['url_test'], 
                $input_array['ws_url'], 
                'Error, Web service url in development, Please call diiferent Service'
            );
            
        }
        elseif($res_db['api_status'] == 2)
        {
            // ws in test
            return $this->check_result_set_response
            (
                $res_db['url_test'], 
                $input_array['ws_url'], 
                'Error, Web service url in testing, Please call diiferent Service'
            );
        }
        elseif($res_db['api_status'] == 3)
        {
            // ws in live
            return $this->check_result_set_response
            (
                $res_db['url_live'], 
                $input_array['ws_url'], 
                'Error, Web service url in live, Please call diiferent Service'
            );
        }
        else
        {
            return array('com_error'  => 'Error, Please call diiferent Service');
        }
    }

    // check result and get response
    private function check_result_set_response($value_one, $value_two, $response)
    {
        if($value_one == $value_two)
        {
            return TRUE;
        }
        else
        {
            return array('com_error' => $response);
        }
    }

}
/* End of file Authentication_lib.php */
/* Location: ./application/libraries/authentication/Authentication_lib.php */
