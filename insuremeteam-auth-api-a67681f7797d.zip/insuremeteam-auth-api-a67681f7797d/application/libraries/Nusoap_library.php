<?php
class Nusoap_library
{
	function __construct() 
	{
		require_once('nusoap/nusoap.php');
	}   
}

?>