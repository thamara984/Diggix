<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * INME Controller
 *
 * @package     bbs
 * @subpackage  core
 * @category    Controller
 * @author      lahiru
 * @link        https://bbs.insureme.lk
 */
class INME_Controller extends CI_Controller
{
    
    // set result
    private $result = array();

    function __construct()
    {
        parent::__construct();
    
    }

    /**
	 * Set response - Success Message
	 *
	 * @param	array success data
	 * @return	array 
	 */
    function set_success_message($data = '')
    {
        $this->result['status']    = 200;
        $this->result['data']      = $data;
        return $this->result;
    }

    /**
	 * Set response - Error Message
	 *
     * @param   int      error format
     * @param   string   error code 
     * @param   string   error message
     * @param	array    error data
     * @return	array 
	 */
    function set_error_message($error_format = 0, $error_code = '', $message = '', $data = '')
    {
        $this->result['status']             = 800;
        $this->result['error_format']       = $error_format;
        $this->result['error']['message']   = $message;
        $this->result['error']['code']      = $error_code;
        $error_format == 1 ? $this->result['error']['errors'] = $data :'';
        return $this->result;
    }

    /**
	 * Set response - Warning Message
	 *
	 * @param   int      warning format
     * @param   string   warning code 
     * @param   string   warning message
     * @param	array    warning data
     * @return	array
	 */
    function set_warning_message($warning_format = 0, $warning_code = '', $message = '', $data = '')
    {
        $this->result['status']               = 700;
        $this->result['warning_format']       = $warning_format;
        $this->result['warning']['message']   = $message;
        $this->result['warning']['code']      = $error_code;
        $warning_format == 1 ? $this->result['warning']['warnings'] = $data :'';
        return $this->result;
    }

    /**
	 * Set response - Information Message
	 *
	 * @param   int      info format
     * @param   string   info code 
     * @param   string   info message
     * @param	array    info data
	 * @return	array 
	 */
    function set_info_message($info_format = 0, $info_code = '', $message = '', $data = '')
    {
        $this->result['status']               = 600;
        $this->result['info_format']          = $info_format;
        $this->result['info']['message']      = $message;
        $this->result['info']['code']         = $info_code;
        $warning_format == 1 ? $this->result['info']['info_array'] = $data :'';
        return $this->result;
    }

    /* Web service format validator */
    function request_format_validate($client_auth, $input_array)
    {
        if(is_array($input_array) && $client_auth <> '')
        {
            $input_array['client_data'] = array
            (
                'auth_key'  => $client_auth
            );
        }
        else
        {
            return FALSE;
        }
        return $input_array;
    }

    /* Common client web service caller */
    function common_nusoap_client_ws_caller($ws_url, $header, $operation, $input_array)
    {
        $client = new nusoap_client($ws_url);
        $client->setHeaders($header);
        $res_common_client_caller = json_decode($client->call($operation, $input_array), TRUE);
        return is_array($res_common_client_caller) ? $res_common_client_caller : $this->set_response('E','Error, Web service request not valid');
    }

    /* Third party application verify */
    function third_party_app_verify($third_req_ws_url, $third_req_ws_operation, $third_req_ws_auth_key, $current_ws_url, $current_auth_key)
    {
        $header = 
        (
            "<auth_key>" . htmlspecialchars($current_auth_key) . "</auth_key>"
        );
        
        $input_array = array
        (
            'input_array' => array
            (
                'ws_utiliies' => array
                (
                    'ws_url'        => $third_req_ws_url,
                    'ws_operation'  => $third_req_ws_operation,
                ),
                'client_data' => array
                (
                    'auth_key' => $third_req_ws_auth_key,
                )
            )
        );

        return $this->common_nusoap_client_ws_caller($current_ws_url, $header, 'auth_key_verify', $input_array);
    }
}
/* End of file INME_Controller.php */
/* Location: ./application/controllers/quotation/INME_Controller.php */