<?php

/*
 * This is to create the validation rules in the whole system
 */

$config = array
(
    'authentication' => array
    (
        array
        (
            'field' => 'api_key',
            'label' => 'API Key',
            'rules' => 'trim|required|alpha_numeric|exact_length[32]'
        ),
        array
        (
            'field' => 'user_name',
            'label' => 'User Name',
            'rules' => 'trim|required|alpha_numeric|min_length[5]|max_length[20]'
        ),
        array
        (
            'field' => 'password',
            'label' => 'Password',
            'rules' => 'trim|required|alpha_numeric|min_length[5]|max_length[32]'
        ),
    ),
    'auth_key_verify'   => array
    (
        array
        (
            'field' => 'ws_auth_key',
            'label' => 'WS auth Key',
            'rules' => 'trim|required|alpha_numeric|max_length[32]'
        ),
        array
        (
            'field' => 'ws_operation',
            'label' => 'WS Operation',
            'rules' => 'trim|required|max_length[20]'
        ),
        array
        (
            'field' => 'ws_url',
            'label' => 'WS URL',
            'rules' => 'trim|required|valid_url'
        ),
        array
        (
            'field' => 'secret_key',
            'label' => 'Client Auth key',
            'rules' => 'trim|required|alpha_numeric|max_length[32]'
        )
    )
);
